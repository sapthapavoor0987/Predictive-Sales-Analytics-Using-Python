import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 1. Load and clean historical data
df = pd.read_csv("historical_sales.csv", parse_dates=["Date"])
df = df.dropna(subset=["Date", "Sales"]).sort_values("Date")
df["Sales"] = pd.to_numeric(df["Sales"], errors="coerce")
df = df.dropna(subset=["Sales"])

# 2. Create time-based features
df["TimeIndex"] = np.arange(len(df))
df["Month"] = df["Date"].dt.month
df["Year"] = df["Date"].dt.year
df["MonthSin"] = np.sin(2 * np.pi * df["Month"] / 12)
df["MonthCos"] = np.cos(2 * np.pi * df["Month"] / 12)

features = ["TimeIndex", "MonthSin", "MonthCos"]

# 3. Time-based train/test split (last 12 months for testing)
train = df.iloc[:-12].copy()
test = df.iloc[-12:].copy()

model = LinearRegression()
model.fit(train[features], train["Sales"])

test["PredictedSales"] = model.predict(test[features])

# 4. Evaluate model accuracy
mae = mean_absolute_error(test["Sales"], test["PredictedSales"])
rmse = np.sqrt(mean_squared_error(test["Sales"], test["PredictedSales"]))
r2 = r2_score(test["Sales"], test["PredictedSales"])

metrics = pd.DataFrame({
    "Metric": ["MAE", "RMSE", "R2 Score"],
    "Value": [mae, rmse, r2]
})
metrics.to_csv("model_metrics.csv", index=False)

# 5. Forecast the next 12 months
future_dates = pd.date_range(
    df["Date"].max() + pd.offsets.MonthBegin(1),
    periods=12,
    freq="MS"
)
future = pd.DataFrame({"Date": future_dates})
future["TimeIndex"] = np.arange(len(df), len(df) + 12)
future["Month"] = future["Date"].dt.month
future["MonthSin"] = np.sin(2 * np.pi * future["Month"] / 12)
future["MonthCos"] = np.cos(2 * np.pi * future["Month"] / 12)
future["ForecastSales"] = model.predict(future[features])
future["ForecastSales"] = future["ForecastSales"].round(0)

future.to_csv("sales_forecast.csv", index=False)

# 6. Save actual vs predicted test results
test[["Date", "Sales", "PredictedSales"]].to_csv(
    "test_predictions.csv", index=False
)

print("Predictive Analytics Results")
print("----------------------------")
print(f"MAE: ₹{mae:,.0f}")
print(f"RMSE: ₹{rmse:,.0f}")
print(f"R² Score: {r2:.3f}")
print("\nNext 12-month forecast:")
print(future[["Date", "ForecastSales"]].to_string(index=False))

# 7. Visualization: historical sales and forecast
plt.figure(figsize=(11, 6))
plt.plot(df["Date"], df["Sales"], label="Historical Sales")
plt.plot(test["Date"], test["PredictedSales"], label="Test Predictions")
plt.plot(future["Date"], future["ForecastSales"], label="Future Forecast")
plt.axvline(test["Date"].iloc[0], linestyle="--", label="Test Period")
plt.title("Historical Sales and Future Forecast")
plt.xlabel("Date")
plt.ylabel("Sales (₹)")
plt.legend()
plt.tight_layout()
plt.savefig("sales_forecast.png", dpi=150)
plt.show()

# 8. Visualization: actual vs predicted
plt.figure(figsize=(8, 6))
plt.scatter(test["Sales"], test["PredictedSales"])
min_val = min(test["Sales"].min(), test["PredictedSales"].min())
max_val = max(test["Sales"].max(), test["PredictedSales"].max())
plt.plot([min_val, max_val], [min_val, max_val], linestyle="--")
plt.title("Actual vs Predicted Sales")
plt.xlabel("Actual Sales (₹)")
plt.ylabel("Predicted Sales (₹)")
plt.tight_layout()
plt.savefig("actual_vs_predicted.png", dpi=150)
plt.show()
