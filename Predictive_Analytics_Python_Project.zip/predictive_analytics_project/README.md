# Predictive Analytics Using Historical Data

A Python machine-learning project that forecasts future monthly sales from historical data.

## Features
- Data cleaning and preprocessing
- Time-based feature engineering
- Regression-based forecasting
- Time-series train/test split
- MAE, RMSE and R² evaluation
- 12-month future sales forecast
- Prediction and forecast visualizations

## Run
```bash
pip install -r requirements.txt
python predictive_analytics.py
```

## Outputs
- `sales_forecast.csv`
- `test_predictions.csv`
- `model_metrics.csv`
- `sales_forecast.png`
- `actual_vs_predicted.png`
